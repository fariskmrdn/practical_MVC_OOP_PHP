<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff</title>
</head>

<body>

    <h1>New Staff Registration Form</h1>
    <form action="" method="POST">
        <div>
            <label for="name">Staff Name</label>
            <input type="text" name="staff_name" id="name" required>
        </div>
        <div style="margin-top: 20px;">
            <label for="name">Staff Email</label>
            <input type="text" name="staff_name" id="name" required>
        </div>
        <div style="margin-top: 20px;">
            <button type="submit">Add Staff</button>
        </div>  
    </form>
    <a href="index.php?action=index">Back to home</a>
</body>

</html>