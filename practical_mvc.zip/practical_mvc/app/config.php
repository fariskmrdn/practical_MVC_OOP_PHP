<?php

require 'database/database.php';

// Set error to be display. Change to 0 for Production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Initialize Database
$database = (new Database())->Connect();

// Initialize Session
session_start();