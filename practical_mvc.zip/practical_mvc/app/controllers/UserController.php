<?php

require 'app/models/User.php';

class UserController {
    // Here you would have methods for CRUD operations

    public function index() {
        // Fetch all users from the database
        // Example: $users = User::all();
        // Load the view to display all users
        require('app/views/index.php');
    }

    public function create() {
        // Load the view for creating a new user
        require('app/views/create.php');
    }

    public function store() {
        // Logic to store the new user in the database
        // Redirect back to the index page
        // header('Location: index.php');
        exit;
    }

    public function edit($id) {
        // Fetch user by ID from the database
        // Example: $user = User::find($id);
        // Load the view for editing the user
        // require('../view/edit.php');
    }

    public function update($id) {
        // Logic to update the user in the database
        // Redirect back to the index page
        // header('Location: index.php');
        exit;
    }

    public function show($id) {
        // Fetch user by ID from the database
        // Example: $user = User::find($id);
        // Load the view to display the user details
        require('app/views/show.php');
    }

    public function destroy($id) {
        // Logic to delete the user from the database
        // Redirect back to the index page
        // header('Location: index.php');
        exit;
    }
}
