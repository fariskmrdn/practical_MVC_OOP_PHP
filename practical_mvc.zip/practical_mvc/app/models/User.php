<?php

class User
{
    private $database;

    public function __construct($database)
    {
        $this->database = $database;
    }

    public function viewUsers()
    {
        $users = $this->database->query("SELECT * FROM users")->fetchAll();
        return $users;
    }

    public function getUser($id)
    {
        $getUser = $this->database->prepare("SELECT * FROM users WHERE id = ?");
        $getUser->execute([$id]);
        $user = $getUser->fetch();
        return $user;
    }
}
