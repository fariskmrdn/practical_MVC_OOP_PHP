<?php 
require 'app/config.php';

// init User Class
$userClass = new User($database);

// call function
$show = $userClass->viewUsers();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First MVC Project</title>
</head>
<body>
    <style>
        .container {
            text-align: center;
        }
    </style>
    <div class="container">
        <h1>Welcome to PHP OOP MVC Project</h1>
        <a href="index.php?action=create" style="margin-bottom:12px; margin-top:20px;">Add Staff</a>

        <center>
            
        <table border="1" cellpadding="12" cellspacing="0">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php foreach($show as $view): ?>
                <tr>
                    <td><?=$view['id']?></td>
                    <td><?=$view['user_name']?></td>
                    <td><?=$view['user_email']?></td>
                    <td>
                        <?= ($view['user_status'] == '1') ? "<b style='color:green;'>Active</b>" : "<b style='color:red;'>Terminated</b>" ?>
                    </td>
                    <td>
                        <a href="index.php?action=show&id=<?=$view['id']?>">Edit</a>
                        <a href="index.php?action=destroy">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        </center>
    </div>
</body>
</html>