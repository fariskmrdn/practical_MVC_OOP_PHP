<?php
require 'app/config.php';

// init User Class
$userClass = new User($database);


$fetchUser = $userClass->getUser($_REQUEST['id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff</title>
</head>

<body>

    <h1>Edit Staff Form</h1>
    <form action="" method="POST">
        <div>
            <label for="name">Staff Name</label>
            <input type="text" name="staff_name" id="name" value="<?= $fetchUser['user_name'] ?>" required>
        </div>
        <div style="margin-top: 20px;">
            <label for="name">Staff Email</label>
            <input type="text" name="staff_name" id="name" value="<?= $fetchUser['user_email'] ?>" required>
        </div>
        <div style="margin-top: 20px;">
            <label for="name">Staff Status</label>
            <select name="" id="">
                <?php
                if ($fetchUser['user_status'] == '1') {
                    ?>
                    <option value="1">Active</option>
                    <option value="0">Terminated</option>
                <?php } else { ?>
                    <option value="0">Terminated</option>
                    <option value="1">Active</option>
                <?php } ?>
            </select>
        </div>
        <div style="margin-top: 20px;">
            <button type="submit">Edit Staff</button>
        </div>
    </form>
    <a href="index.php?action=index">Back to home</a>
</body>

</html>