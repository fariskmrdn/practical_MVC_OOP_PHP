<?php

class Database {
    private $host = 'localhost:3307';
    private $username = 'root';
    private $password = '';
    private $database_name = 'mvc_project';

    private $database;

    public function __construct() {
        try {
            $this->database = new PDO("mysql:host={$this->host}; dbname={$this->database_name}", $this->username, $this->password);
            $this->database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Connection to database is failed! Error as follow : ".$e->getMessage());
        }
    }

    public function Connect() {
        return $this->database;
    }
}